package cn.kgc.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
//调用
//ConfigManager.getInstance().getString ("jdbc.Driver");
//ConfigManager.getInstance().getString("Jdbc.connection.url");
//读取数据库的属性文件，获取数据库的连接信息
//如何只让用户之创建和一个configManager？单例模式1,构造方法先私有2,程序提供给别人唯一对象
//单例模式，有两种实现的方式1，是饿汉方式 和懒汉模式
//这是懒汉模式
public class ConfigManager {
	private  static ConfigManager configManager;
	private Properties properties;
	private ConfigManager(){
		String configFile ="database.properties";
		properties=new Properties(); 
		InputStream in=ConfigManager.class.getClassLoader().getResourceAsStream(configFile);
		try {//读取属性文件
			properties.load(in);
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//提供给别人唯一的一个configManagery对象
	//防止线程不安全加一个锁synchronized
	public static  ConfigManager getInstance(){
		
		if(configManager==null)
		{
			configManager =new ConfigManager();
		}
		return configManager;
	} 
	//根据属性文件中的建拿 到对应的值
	public String getString(String key)
	{
		return properties.getProperty(key);
		
	}
	
}
