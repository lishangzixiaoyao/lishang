package cn.kgc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class NewsDao {
	//查询数据的id 和title；
	public static void main(String[] args) {
		ResultSet rs=null;
		Statement stmt=null;
		Connection connection=null;
		//加载不同的数据库的引擎；（引用jar包）
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://127.0.0.1:3306/kgcnews";
			
			//铺路（获取连接Connection）
			
				 connection =DriverManager.getConnection(url, "root", "root");
				//(下圣旨)
				String sql="SELECT id,title FROM news_detail";
				//找一个小太监执行圣旨（Statement ParsheStatemetn/PreparedStatement）
				
				 stmt=connection.createStatement();
				//拉回西瓜返回的结果（ResultSet）
				 rs=stmt.executeQuery(sql);
				while(rs.next()){
				int id=	rs.getInt("id");
				String title=	rs.getString("title");
				System.out.println(id+"\t"+title);
				}
			 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			
			try {
				rs.close();
				stmt.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
