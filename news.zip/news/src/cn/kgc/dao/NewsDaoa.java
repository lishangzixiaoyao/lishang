package cn.kgc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;


//使用JDBC实现课工场新闻的增删改查
public class NewsDaoa {
	Connection connection=null;
	PreparedStatement pstmt=null;
	ResultSet rs=null;
			
	//提取获取数据库的连接
	public void getConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://127.0.0.1:3306/kgcnews";
			connection=DriverManager.getConnection(url, "root", "root");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//查询新闻标题
	public void getNwesByTitle(String title){
		try {
			this.getConnection();
			String sql="SELECT *from news_detail WHERE title=? ";
			pstmt=connection.prepareStatement(sql);
			pstmt.setString(1, title);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt("id");
				String newsTitle =rs.getString("title");
				System.out.println(id+"\t"+newsTitle);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				rs.close();
				pstmt.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	//增加新闻的信息
	public void addNews(int id,int categoryId,String title,String summary,String content,String author,Date createDate){
	
	try {
		this.getConnection();
		String sql="INSERT INTO news_detail(id,categoryId,title,summary,content,author,createDate) VALUES(?,?,?,?,?,?,?);";
		pstmt=connection.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, categoryId);
		pstmt.setString(3, title);
		pstmt.setString(4, summary);
		pstmt.setString(5, content);
		pstmt.setString(6, author);
		pstmt.setTimestamp(7, new Timestamp(createDate.getTime()));
		//返回的为一个int类型的是一个受影响的行数
		int i=pstmt.executeUpdate();
		if(i>0)
		{
			System.out.println("插入新闻成功！");
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			pstmt.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

	//删除新闻标题
	public void detail(int id){
		
		try {
			this.getConnection();
			String sql="DELETE FROM news_detail WHERE id=?";
			pstmt=connection.prepareStatement(sql);
			pstmt.setInt(1, id);
			int i=pstmt.executeUpdate();
			if(i>0){
				System.out.println("删除新闻成功");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				pstmt.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	//修改新闻标题
	public void updateNews(int id ,String title){
		try {
			this.getConnection();
			String sql="UPDATE news_detail SET title=? WHERE id=?";
			pstmt=connection.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setInt(2, id);
			int i=pstmt.executeUpdate();
			if(i>0){
				System.out.println("修改新闻成功！");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				pstmt.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	//查询全部新闻
	public void getNewsBy(){
		try {
			this.getConnection();
			String sql="SELECT id,categoryId,title,summary,content,author,createDate from news_detail";
			pstmt=connection.prepareStatement(sql);
			System.out.println(sql);
			rs=pstmt.executeQuery();
			while(rs.next())
			{	int id=rs.getInt("id");
				int categoryId =rs.getInt("categoryId");
				String newsTitle=rs.getString("title");
				String summary=rs.getString("summary");
				String content =rs.getString("content");
				String author=rs.getString("author");
				Timestamp createdate =rs.getTimestamp("createDate");
				System.out.println(id+"\t"+categoryId+"\t"+newsTitle+"\t"+summary+"\t"+content+"\t"+author+"\t"+createdate);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			
			try {
				rs.close();
				pstmt.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		NewsDaoa dao=new NewsDaoa();
		//dao.addNews(3, 1, "test", "test", "test", "chenxuan", new Date());
		//dao.updateNews(3, "for");
		dao.detail(3);
		//dao.getNwesByTitle("Java Web开课啦");
		dao.getNewsBy();
		
	}
}

