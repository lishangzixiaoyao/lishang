package cn.kgc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class NewsDaos {
	//使用PreparedStatemnt的安全性比Statement要高
public void getNewsBytitle(String title){
	ResultSet rs=null;
	PreparedStatement pstmt=null;
	Connection connection=null;
	//加载不同的数据库的引擎；（引用jar包）
	try {
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://127.0.0.1:3306/kgcnews";
		
		//铺路（获取连接Connection）
		
			 connection =DriverManager.getConnection(url, "root", "root");
			//(下圣旨)
			//String sql="SELECT *from news_detail WHERE title='"+title+"'";
			 String sql="SELECT *from news_detail WHERE title=?";
			//找一个小太监执行圣旨（Statement /PreparedStatement）
			System.out.println(sql);
			 pstmt=connection.prepareStatement(sql);
			 /*在sql语句的第一个问号的位置填充title；*/
			 pstmt.setString(1, title);
			//拉回西瓜返回的结果（ResultSet）
			 rs=pstmt.executeQuery();
			while(rs.next()){
			int id=	rs.getInt("id");
			String newsTitle=	rs.getString("title");
			System.out.println(id+"\t"+newsTitle);
			}
		 
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally{
		
		try {
			rs.close();
			pstmt.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}
	
		//查询数据特定的标题
	public static void main(String[] args)
	{
		NewsDaos daos=new NewsDaos();
		daos.getNewsBytitle("Java Web开课啦");
		//sql 的漏洞
		//daos.getNewsBytitle("Java Web开课啦'or'1'='1");
	}


}
