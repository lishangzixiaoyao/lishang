package cn.kgc.dao2;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import cn.kgc.dao1.BaseDao;
import cn.kgc.dao1.NewsDaoi;

public class NewsDaoImpl extends BaseDao implements NewsDaoi {
	//查询新闻信息
	public void getNewsList() {
		
		try {
			String sql="select *from news_detail";
			Object[] params={};
			rs=this.executeSQL(sql, params);
			while(rs.next())
			{
				int id=rs.getInt("id");
				String titles=rs.getString("title");
				String title = rs.getString("title");
				String summary = rs.getString("summary");
				String content = rs.getString("content");
				String author = rs.getString("author");
				Timestamp createDate = rs.getTimestamp("createDate");
				System.out.println(id + "\t" + title + "\t" + summary + "\t"
						+ content + "\t" + author + "\t" + createDate);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.closeResource();
		}
		// TODO Auto-generated method stub
		
	}
	//增加新闻信息
	public void add(int id, int categoryId, String title, String summary,
			String content, Date createDate) {
		try {
			String sql="insert into news_detail(id,categoryId,title,summary,content,createDate) values(?,?,?,?,?,?)";
			Object[] params={id, categoryId,title,summary,content, createDate};
			int i=this.executeUpdate(sql, params);
			if(i>0)
			{
				System.out.println("插入新闻成功！");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.closeResource();
		}
		// TODO Auto-generated method stub
		
	}
	//修改新闻标题
	public void update(int id, String title) {
		try {
			String sql = "update news_detail set title=? where id=?";
			Object[] params = {title,id};
			int i = this.executeUpdate(sql,params);
			if (i > 0) {
				System.out.println("修改新闻标题成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			this.closeResource();
		}
		
	}
	//删除新闻信息
	public void delete(int id) {
		
		try {
			String sql = "delete from news_detail where id=?";
			Object[] params ={id};
			int i = this.executeUpdate(sql,params);
			if (i > 0) {
				System.out.println("删除新闻成功！");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			this.closeResource();
		}
	}
		// TODO Auto-generated method stub
		
	
//查询特定标题的新闻信息
	public void getNewsByTitle(String title) {
		// TODO Auto-generated method stub
		try {
			String sql = "select id,title from news_detail where title like ?";
			Object[] params = {title};
			rs = this.executeSQL(sql, params);
			while (rs.next()) {
				int id = rs.getInt("id"); // rs.getInt(1);
				String newsTitle = rs.getString("title");

				System.out.println(id + "\t" + newsTitle);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeResource();
		}
	}
	
	public void getNewsListByDS() {
		try {
			String sql="select *from news_detail";
			Object[] params={};
			rs=this.executeSQL2(sql, params);
			while(rs.next())
			{
				int id=rs.getInt("id");
				String titles=rs.getString("title");
				String title = rs.getString("title");
				String summary = rs.getString("summary");
				String content = rs.getString("content");
				String author = rs.getString("author");
				Timestamp createDate = rs.getTimestamp("createDate");
				System.out.println(id + "\t" + title + "\t" + summary + "\t"
						+ content + "\t" + author + "\t" + createDate);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			this.closeResource();
		}
		// TODO Auto-generated method stub
		
	}
	
	public static void main(String[] args) {
		NewsDaoi newsDao = new NewsDaoImpl();
		//newsDao.add(4, 2, "test","test", "test", new Date());
	//newsDao.update(4,"课工场test"); 
	//		newsDao.delete(4); 
		//newsDao.getNewsList();
	newsDao.getNewsByTitle("%课工场%");
	}

	
}


